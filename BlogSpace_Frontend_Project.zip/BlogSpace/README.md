# BlogSpace — Responsive Blog Application

A beginner-friendly frontend project built with HTML, CSS, and vanilla JavaScript.

## Features
- Responsive Home page with sample blog posts
- Register and Login forms with basic validation
- Dashboard showing posts, word count, and account name
- Create, edit, and delete blog posts
- Posts and demo account data stored in browser `localStorage`
- Mobile navigation and responsive layouts

## Pages
- `index.html` — Home
- `login.html` — Login
- `register.html` — Register
- `dashboard.html` — Dashboard
- `create.html` — Create/Edit Blog

## Run locally
1. Download or clone this repository.
2. Open the folder in VS Code.
3. Open `index.html` in a browser, or use the VS Code Live Server extension.

No build tools or dependencies are required.

## Important
This is a frontend learning/demo application. Passwords are stored in browser localStorage and are **not secure**. Do not use real passwords or deploy this as production authentication. A production app needs a backend, secure password hashing, sessions, and database storage.
